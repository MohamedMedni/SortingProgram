# SortingProgram in java
Sort algorithms are used for ordering items in an array with regard to a predefined order. Here is the implementation of some sorting in Java.

In order to use the sort classes, just add them into your project and create an instance of each sort module and call the related sort method

Exp: java Sort_Main 76 11 -55 2 16 -21 7 88

You can clone or fork repository
Repository URL (https://github.com/MohamedMedni/SortingProgram.git)
